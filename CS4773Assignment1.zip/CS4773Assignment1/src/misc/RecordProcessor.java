package misc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class RecordProcessor {
	private static String [] first_name;//fn to first_name
	private static String [] last_name;//ln to last_name
	private static int [] age;//a to age
	private static String [] pay_type; //ty to type
	private static double [] pay; //py to pay
	private static Scanner list_of_records = null;
	public static String processFile(String inputFile) {
		StringBuffer st = new StringBuffer();
		list_of_records = open_file(inputFile, list_of_records);
		int recordcount = number_of_records(list_of_records);
		list_of_records = open_file(inputFile, list_of_records);
		recordcount = 0;
		recordcount = fill_Records(recordcount);
		
		if(recordcount == 0) {
			System.err.println(inputFile +" :No records found in data file");
			list_of_records.close();
			return null;
		}
		
		//print the rows
		print_rows(st);
		
		int sum1 = 0;
		float avg1 = 0f;
		int c2 = 0;
		double sum2 = 0;
		double avg2 = 0;
		int c3 = 0;
		double sum3 = 0;
		double avg3 = 0;
		int c4 = 0;
		double sum4 = 0;
		double avg4 = 0;
		for(int i = 0; i < first_name.length; i++) {
			sum1 += age[i];
			if(pay_type[i].equals("Commission")) {
				sum2 += pay[i];
				c2++;
			} else if(pay_type[i].equals("Hourly")) {
				sum3 += pay[i];
				c3++;
			} else if(pay_type[i].equals("Salary")) {
				sum4 += pay[i];
				c4++;
			}
		}
		avg1 = (float) sum1 / first_name.length;
		st.append(String.format("\nAverage age:         %12.1f\n", avg1));
		avg2 = sum2 / c2;
		st.append(String.format("Average commission:  $%12.2f\n", avg2));
		avg3 = sum3 / c3;
		st.append(String.format("Average hourly wage: $%12.2f\n", avg3));
		avg4 = sum4 / c4;
		st.append(String.format("Average salary:      $%12.2f\n", avg4));
		
		HashMap<String, Integer> hm = new HashMap<String, Integer>();
		int c1 = 0;
		for(int i = 0; i < first_name.length; i++) {
			if(hm.containsKey(first_name[i])) {
				hm.put(first_name[i], hm.get(first_name[i]) + 1);
				c1++;
			} else {
				hm.put(first_name[i], 1);
			}
		}

		st.append(String.format("\nFirst names with more than one person sharing it:\n"));
		if(c1 > 0) {
			Set<String> set = hm.keySet();
			for(String str : set) {
				if(hm.get(str) > 1) {
					st.append(String.format("%s, # people with this name: %d\n", str, hm.get(str)));
				}
			}
		} else { 
			st.append(String.format("All first names are unique"));
		}

		HashMap<String, Integer> hm2 = new HashMap<String, Integer>();
		int c21 = 0;
		for(int i = 0; i < last_name.length; i++) {
			if(hm2.containsKey(last_name[i])) {
				hm2.put(last_name[i], hm2.get(last_name[i]) + 1);
				c21++;
			} else {
				hm2.put(last_name[i], 1);
			}
		}

		st.append(String.format("\nLast names with more than one person sharing it:\n"));
		if(c21 > 0) {
			Set<String> set = hm2.keySet();
			for(String str : set) {
				if(hm2.get(str) > 1) {
					st.append(String.format("%s, # people with this name: %d\n", str, hm2.get(str)));
				}
			}
		} else { 
			st.append(String.format("All last names are unique"));
		}
		
		//close the file
		list_of_records.close();
		
		return st.toString();
	}
	
	private static void print_rows(StringBuffer st) {
		st.append(String.format("# of people imported: %d\n", first_name.length));
		st.append(String.format("\n%-30s %s  %-12s %12s\n", "Person Name", "Age", "Emp. Type", "Pay"));
		printrow(st,30,"-"," ---  ");
		printrow(st,12,"-"," ");
		printrow(st,12,"-","\n");
		for(int i = 0; i < first_name.length; i++) {
			st.append(String.format("%-30s %-3d  %-12s $%12.2f\n", first_name[i] + " " + last_name[i], age[i]
				, pay_type[i], pay[i]));
		}
	}
	private static void printrow(StringBuffer st,int endLoopCounter,String symbol,String endrow) {
		for(int i = 0; i < endLoopCounter; i++)
			st.append(String.format(symbol));
		st.append(String.format(endrow));
	}
	private static int fill_Records(int recordcount) {
		while(list_of_records.hasNextLine()) {
			String current_rocord = list_of_records.nextLine();
			if(current_rocord.length() > 0) {
				String [] words = current_rocord.split(",");
				int c2 = 0; 
				for(;c2 < last_name.length; c2++) {
					if(last_name[c2] == null)
						break;
					if(last_name[c2].compareTo(words[1]) > 0) {
						for(int i = recordcount; i > c2; i--) {
							first_name[i] = first_name[i - 1];
							last_name[i] = last_name[i - 1];
							age[i] = age[i - 1];
							pay_type[i] = pay_type[i - 1];
							pay[i] = pay[i - 1];
						}
						break;
					}
				}
				
				first_name[c2] = words[0];
				last_name[c2] = words[1];
				pay_type[c2] = words[3];

				try {
					age[c2] = Integer.parseInt(words[2]);
					pay[c2] = Double.parseDouble(words[4]);
				} catch(Exception e) {
					System.err.println(e.getMessage());
					list_of_records.close();
					return -1;
				}
				
				recordcount++;
			}
		}
		return recordcount;
	}
	/*
	 * Change name 
	 * */
	private static void set_values(int recordcount) {
		first_name = new String[recordcount];
		last_name = new String[recordcount];
		age = new int[recordcount];
		pay_type = new String[recordcount];
		pay = new double[recordcount];
	}
	/**
	 * @param inputFile
	 * @param list_of_records
	 * @return
	 */
	private static Scanner open_file(String inputFile, Scanner list_of_records) {
		try {
			list_of_records = new Scanner(new File(inputFile));
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
			return null;
		}
		return list_of_records;
	}
/*
 * Count the number records in the file
 * */
	private static int number_of_records(Scanner file) {
		int count = 0;
		while(file.hasNextLine()) {
			/*rename varible*/
			String l = file.nextLine();
			if(l.length() > 0)
				count++;
		}
		set_values(count);
		file.close();
		return count;
	}
	
}
